Nice Tone Prototype

Key feature:  Capture sound from microphone and determine the pitch

Lib used: https://github.com/AudioKit/AudioKit
